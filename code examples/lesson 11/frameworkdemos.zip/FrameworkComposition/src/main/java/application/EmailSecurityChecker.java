package application;

public class EmailSecurityChecker {
	public boolean isEmailSecure(String emailAddress, String message) {
		return true;
	}
}
