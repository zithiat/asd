package framework;

public interface EmailSender {
	void send(String emailAddress, String message);

}
