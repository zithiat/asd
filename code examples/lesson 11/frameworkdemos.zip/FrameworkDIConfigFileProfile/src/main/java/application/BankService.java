package application;



public interface BankService {
	public void deposit() ;
}
