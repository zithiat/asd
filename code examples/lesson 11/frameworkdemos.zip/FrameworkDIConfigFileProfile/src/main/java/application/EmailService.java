package application;

public interface EmailService {
	void send(String content);

}
