package accountpackage;

public interface IAccountService {
	public void addAccount(String accountNumber, Customer customer);
}
