package accountpackage;

public class Customer {
	private String name;

	public Customer(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + "]";
	}

}
