package observer.push.multiple.subjects;

public interface StockValueObserver {
  public void update(Stock stock);
}
