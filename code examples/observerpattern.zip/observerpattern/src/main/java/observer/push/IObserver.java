package observer.push;

public interface IObserver {
  public void update(Stock stock);
}
