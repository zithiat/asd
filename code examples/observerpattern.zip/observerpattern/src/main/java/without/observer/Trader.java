package without.observer;

public class Trader {

	public void trade(Stock stock) {
		System.out.println("Trader trade stock :" + stock);
	}
}
