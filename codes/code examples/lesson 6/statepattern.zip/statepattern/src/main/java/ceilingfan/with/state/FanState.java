package ceilingfan.with.state;

public interface FanState {
   void pullred();
   void pullgreen();
}
