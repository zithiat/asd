package threadsafe2;

public class Connection {
	public void open() {
		System.out.println("open connection to DB");
	}
}
