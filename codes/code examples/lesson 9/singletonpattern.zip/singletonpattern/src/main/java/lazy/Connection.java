package lazy;

public class Connection {
	public void open() {
		System.out.println("open connection to DB");
	}
}
