package factorymethod;

public interface PhoneFactory {
   Phone getPhone();
}
