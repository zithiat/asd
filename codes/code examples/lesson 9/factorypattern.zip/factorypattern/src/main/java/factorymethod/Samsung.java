package factorymethod;

public class Samsung extends Phone{

	@Override
	public String getName() {
		return "Samsung phone";
	}
}
