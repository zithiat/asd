package factorymethod;

public abstract class Phone {
	public abstract String getName();

}
