package factorymethod;

public class IPhone extends Phone{

	@Override
	public String getName() {
		return "Iphone";
	}

}
