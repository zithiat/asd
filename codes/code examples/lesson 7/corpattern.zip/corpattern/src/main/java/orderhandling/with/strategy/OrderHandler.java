package orderhandling.with.strategy;

public interface OrderHandler {
	public void handleOrder(String orderContent);
}
