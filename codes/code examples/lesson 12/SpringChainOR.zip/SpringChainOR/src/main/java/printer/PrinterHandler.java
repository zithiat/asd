package printer;

public interface PrinterHandler {
	public boolean handle(PrintProperties PrinterProperties, String content);
}
