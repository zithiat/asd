package abstractfactory;

public class Customer {
	private String name;

	public Customer(String name) {
		super();
		this.name = name;
	}

}
