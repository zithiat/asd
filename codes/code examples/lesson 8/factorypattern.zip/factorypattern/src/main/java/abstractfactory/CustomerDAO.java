package abstractfactory;

public interface CustomerDAO {
	void save(Customer customer);
}
