package abstractfactory;

public interface ProductDAO {
  void save(Product product);
}
