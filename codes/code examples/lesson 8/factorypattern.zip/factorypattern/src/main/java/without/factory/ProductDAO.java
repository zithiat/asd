package without.factory;

public interface ProductDAO {
  void save(Product product);
}
